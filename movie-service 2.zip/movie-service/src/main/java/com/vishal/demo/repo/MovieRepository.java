package com.vishal.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.demo.entity.Movie;


public interface MovieRepository extends JpaRepository<Movie, Integer> {

}