package com.vishal.demo.service;

import com.vishal.demo.entity.Movie;
import com.vishal.demo.vo.CinemaTemplate;

public interface MovieService {

	Movie save(Movie m);
	
	Movie find(int id);
	
	CinemaTemplate details(int id);
}