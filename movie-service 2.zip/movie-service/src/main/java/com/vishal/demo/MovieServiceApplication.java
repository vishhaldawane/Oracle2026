package com.vishal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class MovieServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieServiceApplication.class, args);
		System.out.println("Movie Service started...");
	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		System.out.println("RestTemplate created....");
		return new RestTemplate();
	}
}
