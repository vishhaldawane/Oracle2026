package com.vishal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="head1")
public class Head {

	@Id
	int headId;
	
	@Column(length=20)
	String headName;
	
	@Column(name="experience")
	int numberOfYearsExperience;
	
	@OneToOne
	@JoinColumn(name="dno") //Foreign key
	Department heading; //hasA
}











