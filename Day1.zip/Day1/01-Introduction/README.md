# Topic 1 — Introduction to Oracle JET
**Duration:** 45–60 minutes | **Level progression:** Concept → Basic → Intermediate → Advanced

## Learning Objectives
By the end of this session, learners will be able to:
1. Explain what Oracle JET is and the problem it solves
2. Describe the JET architecture (layers: 3rd-party libs, oj-core, oj-components/oj-c pack, Composite Components)
3. Identify when to choose JET vs. other SPA frameworks
4. Recognize the two component families: legacy `oj-*` (Knockout-based) and the newer `oj-c-*` (Preact/VDOM "JET Pack")

## Talking Points / Trainer Notes
- Oracle JET (JavaScript Extension Toolkit) is a **free, open-source, modular toolkit** (Apache 2.0) maintained by Oracle
  for building enterprise-grade, accessible, responsive web applications — especially ones that talk to Oracle back
  ends (REST, ADF BC, Fusion Apps) but works with any REST/JSON backend.
- It is **not a single framework** — it bundles and glues together proven open-source libraries:
  RequireJS, Knockout.js, jQuery/jQueryUI, Preact (in newer versions), Hammer.js, and its own `oj-*` UI component
  library + CSS layer.
- Layers (see diagram in slide deck):
  1. **3rd-party layer** — RequireJS (AMD loader), Knockout (data-binding/MVVM), Preact (VDOM rendering for oj-c)
  2. **oj-core / ojs layer** — base classes: DataProvider, Validation, Router, Model/Collection, ResponsiveUtils
  3. **UI Component layer** — `oj-*` (Custom Elements, Knockout-bound) and `oj-c-*` (lightweight VDOM "Pack" components)
  4. **Composite Component layer** — your own reusable custom elements built from the above
- Enterprise strengths: accessibility (WCAG/Section 508) baked in, internationalization/bidi, theming (Redwood),
  and a CLI (`ojet-cli`) for scaffolding, building, and packaging (web + hybrid mobile via Cordova).

## Folder Contents
| Folder | What it demonstrates |
|---|---|
| `01-basic` | A single self-contained HTML page — "Hello JET" — shows the toolkit loading and rendering one component |
| `02-intermediate` | Compares a plain-JS card vs. a JET `oj-*` card component, showing built-in theming/accessibility for free |
| `03-advanced` | A mini "architecture tour" page that loads a component from each layer (3rd-party, core, oj-*, oj-c-*, and a custom Composite Component) side by side, so learners can see the layers physically working together |

## How to Run
Every example in this course is a **single HTML file** that loads Oracle JET from Oracle's public CDN via
RequireJS — no Node.js/npm install is required for Day-1 basic/intermediate examples. Just double-click the
`index.html` file, or open it with a local file server (e.g. VS Code "Live Server" extension) for best results.

> **Trainer note on CDN version:** These examples pin a specific Oracle JET CDN version at the top of each file in
> a single `JET_VERSION` comment. Before class, verify the latest available version at
> `https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html` (Cookbook → "Use JET from CDN") and update
> the version string in each file if needed — the API used in these exercises is stable across recent versions.
