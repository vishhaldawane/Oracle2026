// Registers <demo-badge> as a JET Composite Component (VComponent-lite pattern via ojComposite).
// This is the classic Composite Component API - the same pattern used for enterprise-shared
// component libraries.
define(['ojs/ojcomposite', 'text!./demo-badge-view.html', './demo-badge-viewModel', 'text!./component.json'],
  function (Composite, view, viewModel, metadata) {
    Composite.register('demo-badge', {
      metadata: JSON.parse(metadata),
      view: view,
      viewModel: viewModel
    });
  });
