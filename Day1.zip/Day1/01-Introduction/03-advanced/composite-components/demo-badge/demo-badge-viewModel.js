define([], function () {
  function DemoBadgeViewModel(context) {
    // context.properties gives read access to the properties declared in component.json
    this.name = context.properties.name;
    this.role = context.properties.role;
  }
  return DemoBadgeViewModel;
});
