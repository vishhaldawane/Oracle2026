# Topic 3 — Responsive UI
**Duration:** 60 minutes

## Learning Objectives
1. Use JET's responsive grid utility classes (`oj-sm-*`, `oj-md-*`, `oj-lg-*`, `oj-xl-*`)
2. Build a responsive off-canvas navigation pattern for mobile
3. React to breakpoint changes programmatically with `ResponsiveUtils` / `ResponsiveKnockoutUtils`

## Breakpoints (memorize these — they appear on the exam/quiz)
| Class prefix | Breakpoint | Approx. width |
|---|---|---|
| `oj-sm-*` | Small | ≥ 0px (phones) |
| `oj-md-*` | Medium | ≥ 768px (tablets) |
| `oj-lg-*` | Large | ≥ 1024px (small desktops) |
| `oj-xl-*` | Extra Large | ≥ 1280px (wide desktops) |

## Folder Contents
| Folder | What it demonstrates |
|---|---|
| `01-basic` | 12-column responsive grid: 1 column on phones, 2 on tablets, 4 on desktop — using only CSS classes |
| `02-intermediate` | Responsive off-canvas navigation drawer that auto-collapses on small screens |
| `03-advanced` | A full dashboard combining grid + off-canvas + JS-driven breakpoint logic (swap a table for cards on mobile) |
