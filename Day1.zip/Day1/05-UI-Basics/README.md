# Topic 5 — Understanding Oracle JET UI Basics
**Duration:** 2 hours (the biggest single block on Day 1 — hands-on heavy)

## Learning Objectives
1. Use the most common `oj-*` form and action components (`oj-button`, `oj-input-text`,
   `oj-select-single`, `oj-switch`, `oj-form-layout`)
2. Bind collection components (`oj-table`, `oj-list-view`) to a `DataProvider`
3. Build your own reusable UI element using the **Composite Component** architecture

## Component Family Cheat-Sheet
| Category | Components |
|---|---|
| Action | `oj-button`, `oj-menu-button`, `oj-buttonset-one` |
| Input/Form | `oj-input-text`, `oj-input-number`, `oj-select-single`, `oj-select-many`, `oj-switch`, `oj-checkboxset`, `oj-radioset`, `oj-form-layout`, `oj-label` |
| Collection | `oj-table`, `oj-list-view`, `oj-data-grid`, `oj-tree-view` |
| Navigation | `oj-navigation-list`, `oj-tab-bar`, `oj-menu` |
| Layout | `oj-form-layout`, `oj-panel`, `oj-flex`/`oj-flex-item` |
| Feedback | `oj-messages`, `oj-progress-bar`, `oj-dialog` |

## Folder Contents
| Folder | What it demonstrates |
|---|---|
| `01-basic` | A components "tour" form: button, input-text, select-single, switch, form-layout |
| `02-intermediate` | `oj-table` and `oj-list-view` bound to an `ArrayDataProvider`, with sorting and selection |
| `03-advanced` | Building a reusable `<star-rating>` Composite Component from scratch (metadata.json + view + view model), then consuming it like any other `oj-*` element |
