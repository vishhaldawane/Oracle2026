define(['knockout'], function (ko) {
  function StarRatingViewModel(context) {
    var self = this;
    var props = context.properties;   // read-only snapshot + writeback helpers
    var element = context.element;

    self.value = ko.observable(props.value || 0);
    self.stars = [];
    for (var i = 1; i <= (props.max || 5); i++) { self.stars.push(i); }

    self.selectStar = function (starNumber) {
      if (props.readOnly) { return; }
      self.value(starNumber);
      // 1. writeback the bindable "value" property so {{rating}} in the consumer updates
      context.props = context.props || {};
      element.setProperty('value', starNumber);
      // 2. fire the custom "ratingChanged" event declared in component.json
      element.dispatchEvent(new CustomEvent('ratingChanged', { detail: { value: starNumber } }));
    };
  }
  return StarRatingViewModel;
});
