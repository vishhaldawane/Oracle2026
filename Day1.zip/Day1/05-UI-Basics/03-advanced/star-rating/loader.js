// Registers <star-rating> as a Composite Component.
define(['ojs/ojcomposite', 'text!./star-rating-view.html', './star-rating-viewModel',
        'text!./component.json', 'css!./star-rating-styles'],
  function (Composite, view, ViewModel, metadata) {
    Composite.register('star-rating', {
      metadata: JSON.parse(metadata),
      view: view,
      viewModel: ViewModel
    });
  });
