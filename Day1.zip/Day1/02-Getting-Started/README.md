# Topic 2 — Getting Started with Oracle JET
**Duration:** 75–90 minutes

## Learning Objectives
1. Stand up a JET page instantly via CDN (no install) for quick prototyping
2. Install `@oracle/ojet-cli` and scaffold a real project the officially supported way
3. Understand the generated project's folder structure
4. Build, serve, and produce a production (release) bundle

## Prerequisites for the Intermediate/Advanced Exercises
```bash
node -v      # Node.js 18 LTS or later recommended
npm install -g @oracle/ojet-cli
ojet --version
```

## Folder Contents
| Folder | What it demonstrates |
|---|---|
| `01-basic` | CDN quick-start (open the HTML file directly) — good for the first 15 minutes of class |
| `02-intermediate` | `ojet-cli` scaffolding walkthrough — commands + the exact source files to paste into the generated project |
| `03-advanced` | Multi-module app, path-mapping customization, and production/release build + hybrid (Cordova) packaging overview |

## Trainer Walkthrough — `ojet-cli` (do this live in class)
```bash
# 1. Scaffold a new web app using the Redwood theme, VDOM (JET Pack) template
ojet create my-first-app --template=basic

# 2. Move into the project and look at the structure (see 02-intermediate/PROJECT-STRUCTURE.md)
cd my-first-app

# 3. Serve locally with live reload
ojet serve

# 4. Build a production bundle (minified, no source maps)
ojet build --release

# 5. (Optional) Add a hybrid mobile target
ojet add hybrid --platforms=android,ios
```
