# Advanced — Multi-module app, path mapping, production build & hybrid packaging

## 1. Adding a second/third module (page)
```bash
# Add a new empty view + viewModel pair, and register the route in appController.js
touch src/js/views/employees.html
touch src/js/viewModels/employees.js
```
Then add a route entry in `appController.js`:
```js
self.router = new CoreRouter([
  { path: '', redirect: 'home' },
  { path: 'home', detail: { label: 'Home' } },
  { path: 'employees', detail: { label: 'Employees' } },
  { path: 'about', detail: { label: 'About' } }
], { urlAdapter: new CoreRouter.UrlPathAdapter('/my-first-app/') });
```

## 2. Customizing `path_mapping.json` (adding a 3rd-party library, e.g. Chart.js or lodash)
```bash
npm install lodash --save
```
```json
{
  "lodash": {
    "cdn": { "path": "https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min", "requireConfig": {} },
    "npm": { "path": "lodash/lodash.min" },
    "debug": { "path": "lodash/lodash" }
  }
}
```
Then simply `require(['lodash'], function(_) { ... })` anywhere in the app — the CLI's build
process resolves the right file for dev vs. release, and (if configured) from CDN vs. bundled.

## 3. Production release build
```bash
ojet build --release
# Output: web/ folder - minified JS/CSS bundles, cache-busted filenames, debug code stripped
```
Compare bundle sizes:
```bash
ojet build           # debug build -> readable stack traces, larger files
ojet build --release # release build -> minified, smaller, no console warnings from JET internals
du -sh web/js/*.js
```

## 4. Packaging as a hybrid mobile app (Cordova)
```bash
ojet add hybrid --platforms=android,ios
ojet build android --release
ojet serve android --emulator
```
This wraps the exact same JET web app in a Cordova shell so it can be distributed through app stores,
while sharing 100% of the JET UI code with the web build — a key selling point of the toolkit for
enterprises that need both a browser app and a mobile app from one codebase.

## Discussion Points for the Class
- When would you choose `webpack.config.js` customization over the default CLI build?
- How do path mappings let you swap in an internal corporate CDN in production, but use node_modules in dev?
- What's the tradeoff of hybrid (Cordova) vs. a native app for a given business requirement?
