// PASTE INTO: my-first-app/src/js/appController.js
define(['ojs/ojcore', 'knockout', 'ojs/ojmodulerouter-adapter', 'ojs/ojcorerouter',
        'ojs/ojknockouttemplateutils', 'ojs/ojmodule-element-utils',
        'ojs/ojknockout', 'ojs/ojmodule-element'],
  function (oj, ko, ModuleRouterAdapter, CoreRouter, KnockoutTemplateUtils, ModuleElementUtils) {

    function ControllerViewModel() {
      var self = this;
      self.appName = ko.observable('My First App');

      // The CoreRouter is the heart of Oracle JET's Single Page Application navigation
      // (see Topic 4 - Single Page Applications for a deep dive)
      self.router = new CoreRouter([
        { path: '', redirect: 'home' },
        { path: 'home', detail: { label: 'Home' } },
        { path: 'about', detail: { label: 'About' } }
      ], { urlAdapter: new CoreRouter.UrlPathAdapter('/my-first-app/') });

      self.moduleAdapter = new ModuleRouterAdapter(self.router);
      self.moduleConfig = self.moduleAdapter.moduleConfig;

      self.router.sync();
    }

    return new ControllerViewModel();
  });
