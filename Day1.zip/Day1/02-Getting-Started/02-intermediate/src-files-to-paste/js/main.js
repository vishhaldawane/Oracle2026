// PASTE INTO: my-first-app/src/js/main.js
requirejs(['ojs/ojbootstrap', 'appController', 'knockout', 'ojs/ojknockout'],
  function (Bootstrap, app, ko) {
    Bootstrap.whenDocumentReady().then(function () {
      ko.applyBindings(app, document.getElementById('globalBody'));
    });
  });
