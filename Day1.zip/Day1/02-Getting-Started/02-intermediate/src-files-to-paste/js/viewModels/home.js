define([], function () {
  function HomeViewModel() {
    // this.connected()/this.disconnected() hooks are available for module lifecycle needs
  }
  return HomeViewModel;
});
