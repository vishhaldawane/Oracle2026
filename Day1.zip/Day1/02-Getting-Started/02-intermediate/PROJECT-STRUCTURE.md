# Anatomy of an `ojet create` project

```
my-first-app/
├── src/
│   ├── index.html            # Application shell — loads main.js, has the <div id="globalBody">
│   ├── js/
│   │   ├── main.js           # RequireJS bootstrap — registers Knockout components + starts router
│   │   ├── appController.js  # Root view model: app name, current nav item, router setup
│   │   ├── views/            # One .html per "page" (Knockout templates)
│   │   └── viewModels/        # One .js per "page" (view model logic paired with a view)
│   ├── css/
│   │   └── app.css           # Your app-specific overrides (theme comes from oraclejet package)
│   └── themes/               # Optional custom SASS theme overrides (see Topic 8 - Theming)
├── scripts/
│   ├── config/oraclejetconfig.json  # ojet-cli project config: theme, platforms, paths
│   └── hooks/                        # before_build / after_build custom build hooks
├── path_mapping.json         # Maps bundle names -> library files (edit when adding 3rd-party libs)
├── package.json               # npm dependencies incl. @oracle/oraclejet
└── webpack.config.js          # (newer templates) Webpack build configuration
```

## Key Concepts to Emphasize
- **`ojet serve`** runs a dev server with live reload and *debug* (unminified) JET bundles for readable stack traces.
- **`ojet build --release`** produces *minified* bundles, strips debug-only checks, and is what you deploy.
- **`oraclejetconfig.json`** is the single source of truth for which theme, platforms, and TypeScript/JS mode the CLI uses.
- Templates: `--template=basic` (single view), `--template=navbar` (nav bar + router), `--template=navdrawer` (side drawer + router) — pick `navdrawer` for most enterprise apps (see Topic 4 - SPA).
