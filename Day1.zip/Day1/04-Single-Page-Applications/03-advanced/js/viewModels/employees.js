define(['ojs/ojcorerouter', 'ojs/ojarraydataprovider', 'knockout'],
  function (CoreRouter, ArrayDataProvider, ko) {

    function EmployeesViewModel(context) {
      var self = this;

      var employees = [
        { id: '1', name: 'Priya Rao' },
        { id: '2', name: 'John Diaz' },
        { id: '3', name: 'Amara Obi' }
      ];
      self.dataProvider = new ArrayDataProvider(employees, { keyAttributes: 'id' });
      self.selectedId = ko.observable(null);
      self.selectedName = ko.observable('');

      // CHILD router, scoped under the parent route "employees" - this is the drill-down pattern
      self.childRouter = context.parentRouter.createChildRouter([
        { path: '', detail: { label: 'List' } },
        { path: ':id', detail: { label: 'Detail' } }
      ]).sync();

      self.childRouter.currentState.subscribe(function (state) {
        if (state && state.path && state.path !== '') {
          var emp = employees.filter(function (e) { return e.id === state.path; })[0];
          self.selectedId(state.path);
          self.selectedName(emp ? emp.name : 'Unknown');
        } else {
          self.selectedId(null);
        }
      });

      self.openDetail = function (event) {
        var id = event.detail.context.data.id;
        self.childRouter.go({ path: id });
      };

      self.backToList = function () {
        self.childRouter.go({ path: '' });
      };
    }

    return EmployeesViewModel;
  });
