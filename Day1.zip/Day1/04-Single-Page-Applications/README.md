# Topic 4 — Single Page Applications (SPA) with Oracle JET
**Duration:** 90 minutes

## Learning Objectives
1. Understand why SPAs avoid full-page reloads and how `CoreRouter` enables that in JET
2. Wire an `oj-navigation-list` to a router and animate module transitions
3. Build nested (parent/child) routers for master-detail drill-down navigation with deep-linking

## Core Concept — the SPA Navigation Diagram
```
   Browser URL bar               CoreRouter                 oj-module / ModuleRouterAdapter
   /app/employees/42   <----->  matches route  ----->  loads viewModels/employee-detail.js
        ^                          |                          + views/employee-detail.html
        |                          v                                    |
        +----- history.pushState  updates <-------------- renders INTO the SAME page
                                                            (no full reload!)
```
Only the `<div data-bind="ojModule: moduleConfig">` region re-renders. The header, nav list, and
footer stay mounted — this is what makes it feel instant compared to classic multi-page apps.

## Folder Contents
| Folder | What it demonstrates |
|---|---|
| `01-basic` | Two views (`home`, `about`) switched by `CoreRouter` + `oj-module` — no page reload |
| `02-intermediate` | `oj-navigation-list` bound to the router, plus `oj-module-animation` for slide transitions |
| `03-advanced` | Nested routers for master-detail drill-down (`/employees` list → `/employees/{id}` detail), with deep-linking support |
