function fib(n) {
  return n < 2 ? n : fib(n - 1) + fib(n - 2);
}

onmessage = (event) => {
  const n = event.data.number;
  const start = performance.now();
  const result = fib(n);
  const duration = (performance.now() - start).toFixed(1);
  postMessage({ result, duration });
};
