const express = require('express');
const path = require('path');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve everything in /public as static files
app.use(express.static(path.join(__dirname, 'public')));

// Create HTTP server so Express and WebSocket can share the same port
const server = http.createServer(app);

// Attach a WebSocket server on top of the same HTTP server
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  console.log('Client connected');
  ws.send('Welcome! You are connected to the WebSocket server.');

  ws.on('message', (message) => {
    const text = message.toString();
    console.log('Received:', text);

    // Echo back to sender
    ws.send(`Server echo: ${text}`);

    // Broadcast to all other connected clients
    wss.clients.forEach((client) => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(`Another client says: ${text}`);
      }
    });
  });

  ws.on('close', () => console.log('Client disconnected'));
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`WebSocket available at ws://localhost:${PORT}`);
});
