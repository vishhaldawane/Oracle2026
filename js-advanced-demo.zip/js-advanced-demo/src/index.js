import { add, factorial, greet } from './mathUtils.js';

function render() {
  const output = document.getElementById('output');
  const lines = [
    greet('Developer'),
    `add(5, 7) = ${add(5, 7)}`,
    `factorial(6) = ${factorial(6)}`,
    'This entire message came from a minified, bundled production file (bundle.js) built by Webpack from multiple ES module source files.',
  ];
  output.innerHTML = lines.map(l => `<p>${l}</p>`).join('');
}

document.addEventListener('DOMContentLoaded', render);
