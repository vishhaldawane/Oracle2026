export function add(a, b) {
  return a + b;
}

export function factorial(n) {
  return n <= 1 ? 1 : n * factorial(n - 1);
}

export function greet(name) {
  return `Hello, ${name}! This bundle was built with Webpack.`;
}
