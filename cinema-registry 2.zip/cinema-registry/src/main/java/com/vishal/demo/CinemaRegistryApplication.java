package com.vishal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class CinemaRegistryApplication {
//http://localhost:8761
	public static void main(String[] args) {
		SpringApplication.run(CinemaRegistryApplication.class, args);
		System.out.println("Eureka Server Started.....");
	}

}
