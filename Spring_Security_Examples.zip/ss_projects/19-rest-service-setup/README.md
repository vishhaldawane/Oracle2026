# Topic 19 — The REST Service and Its Setup

Maps to Spring Security pptx, Topic 19/25.

## Concept
A dedicated `SecurityFilterChain` matched to `/api/**` uses
`SessionCreationPolicy.STATELESS` (no server-side session), disables CSRF
(safe for stateless, token/credential-per-request APIs), and returns a JSON
401 instead of an HTML redirect when authentication is missing.

## Run
```
mvn spring-boot:run
curl -i http://localhost:8080/api/orders                     # 401 JSON body
curl -u api-user:api-pass http://localhost:8080/api/orders    # 200 JSON list
```
