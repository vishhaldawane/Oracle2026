package com.example.demo;

import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {

    @GetMapping("/api/orders")
    public List<Map<String, Object>> orders() {
        return List.of(
            Map.of("id", 101, "item", "Keyboard"),
            Map.of("id", 102, "item", "Monitor")
        );
    }
}
