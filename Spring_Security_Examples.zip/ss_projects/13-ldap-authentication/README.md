# Topic 13 — Authentication with LDAP

Maps to Spring Security pptx, Topic 13/25.

## Concept
`LdapAuthenticationProvider` (wrapping a `BindAuthenticator`) authenticates by
binding to the directory with the username/password the user typed in —
your app never stores or sees a reusable password hash.

This project runs a real **embedded** LDAP server (via UnboundID) seeded from
`ldap-data.ldif`, so it works standalone with no external directory.

## Run
```
mvn spring-boot:run
curl -u alex:pass123 http://localhost:8080/
curl -u bob:wrongpass http://localhost:8080/   # 401
```
