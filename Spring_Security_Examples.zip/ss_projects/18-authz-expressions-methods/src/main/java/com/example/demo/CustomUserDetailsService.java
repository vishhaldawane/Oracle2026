package com.example.demo;

import java.util.List;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final String encodedPass = PasswordEncoderFactories.createDelegatingPasswordEncoder().encode("pass");

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if ("alex".equals(username)) {
            return new CustomUserPrincipal(1L, "alex", encodedPass, List.of(new SimpleGrantedAuthority("ROLE_USER")));
        }
        if ("admin".equals(username)) {
            return new CustomUserPrincipal(99L, "admin", encodedPass, List.of(new SimpleGrantedAuthority("ROLE_ADMIN")));
        }
        throw new UsernameNotFoundException(username);
    }
}
