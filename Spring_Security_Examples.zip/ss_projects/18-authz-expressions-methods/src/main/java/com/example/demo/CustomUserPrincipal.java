package com.example.demo;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

/** Extends the default User so #authentication.principal.id is available in @PreAuthorize. */
public class CustomUserPrincipal extends User {

    private final Long id;

    public CustomUserPrincipal(Long id, String username, String password, Collection<? extends GrantedAuthority> authorities) {
        super(username, password, authorities);
        this.id = id;
    }

    public Long getId() { return id; }
}
