package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired private OrderService orderService;

    @GetMapping("/orders/{id}")
    public String order(@PathVariable Long id) {
        return orderService.getOrder(id);
    }
}
