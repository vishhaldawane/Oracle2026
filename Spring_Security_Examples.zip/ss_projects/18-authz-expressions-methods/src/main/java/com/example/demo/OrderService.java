package com.example.demo;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    // Order #1 belongs to user id 1 (alex).
    @PreAuthorize("#id == authentication.principal.id or hasRole('ADMIN')")
    public String getOrder(Long id) {
        return "Order #" + id + " — only its owner (or an ADMIN) may fetch it.";
    }
}
