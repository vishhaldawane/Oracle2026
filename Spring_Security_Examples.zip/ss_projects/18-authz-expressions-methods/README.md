# Topic 18 — Authorization with Expressions: on Methods

Maps to Spring Security pptx, Topic 18/25.

## Concept
`@EnableMethodSecurity` + `@PreAuthorize` enforces domain rules ("only the
owner may see this") exactly where the business logic runs, using a custom
principal (`CustomUserPrincipal`) that exposes an `id` field to the SpEL
expression.

## Run
```
mvn spring-boot:run
curl -u alex:pass  http://localhost:8080/orders/1    # 200 — alex's own id is 1
curl -u alex:pass  http://localhost:8080/orders/2    # 403 — not alex's order
curl -u admin:pass http://localhost:8080/orders/2    # 200 — ADMIN overrides ownership
```
