# Topic 15 — Authentication & Authorization: External LDAP Server

Maps to Spring Security pptx, Topic 15/25.

## Concept
Moving from the embedded test directory (Topics 13-14) to a real external
LDAP/AD server introduces production concerns: TLS (`ldaps://`), a dedicated
bind/service account instead of a real user, connection pooling, and a
directory-specific search filter (Active Directory uses `sAMAccountName`,
not the generic `uid`).

## Run
Edit `src/main/resources/application.properties` (or pass `-D` system
properties / environment variables) with your real directory's URL, base DN,
and bind credentials, then:
```
mvn spring-boot:run
curl -u yourAdUsername:yourAdPassword http://localhost:8080/
```
This project needs network access to an actual LDAP/AD server to run
end-to-end — it is intentionally a configuration reference rather than a
self-contained demo like Topics 13-14.
