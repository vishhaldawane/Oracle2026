package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.ldap.authentication.BindAuthenticator;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Same authentication/authorization approach as Topics 13-14, but pointed at
 * a REAL external LDAP/Active Directory server via environment-driven
 * properties instead of the embedded test directory. You must have network
 * access to a real directory server to run this one end-to-end.
 */
@Configuration
public class SecurityConfig {

    @Value("${app.ldap.url}")
    private String ldapUrl;

    @Value("${app.ldap.base}")
    private String ldapBase;

    @Value("${app.ldap.bind-user}")
    private String bindUser;

    @Value("${app.ldap.bind-password}")
    private String bindPassword;

    @Bean
    public LdapContextSource contextSource() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(ldapUrl);          // e.g. ldaps://corp-ad.company.com:636
        contextSource.setBase(ldapBase);         // e.g. dc=company,dc=com
        contextSource.setUserDn(bindUser);       // dedicated service/bind account — never a real user
        contextSource.setPassword(bindPassword);
        contextSource.setPooled(true);           // enable connection pooling for production use
        return contextSource;
    }

    @Bean
    public BindAuthenticator bindAuthenticator(LdapContextSource contextSource) {
        BindAuthenticator authenticator = new BindAuthenticator(contextSource);
        // Active Directory typically authenticates by userPrincipalName / sAMAccountName,
        // adjust the filter to match your real directory's schema.
        authenticator.setUserSearchFilter("(sAMAccountName={0})");
        authenticator.setUserSearchBase("");
        return authenticator;
    }

    @Bean
    public DefaultLdapAuthoritiesPopulator authoritiesPopulator(LdapContextSource contextSource) {
        DefaultLdapAuthoritiesPopulator populator =
                new DefaultLdapAuthoritiesPopulator(contextSource, "ou=groups");
        populator.setGroupSearchFilter("member={0}");
        populator.setRolePrefix("ROLE_");
        populator.setConvertToUpperCase(true);
        return populator;
    }

    @Bean
    public AuthenticationProvider ldapAuthenticationProvider(
            BindAuthenticator bindAuthenticator, DefaultLdapAuthoritiesPopulator authoritiesPopulator) {
        return new LdapAuthenticationProvider(bindAuthenticator, authoritiesPopulator);
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationProvider ldapAuthenticationProvider) {
        return new ProviderManager(ldapAuthenticationProvider);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth.anyRequest().authenticated())
            .httpBasic(Customizer.withDefaults());
        return http.build();
    }
}
