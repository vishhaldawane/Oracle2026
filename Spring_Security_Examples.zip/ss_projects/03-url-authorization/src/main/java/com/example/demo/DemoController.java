package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @GetMapping("/api/public/info")
    public String publicInfo() {
        return "Anyone can read this — no authentication required.";
    }

    @GetMapping("/user/profile")
    public String userProfile() {
        return "Any authenticated user (USER or ADMIN role) can see this.";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard() {
        return "Only ROLE_ADMIN can see this.";
    }
}
