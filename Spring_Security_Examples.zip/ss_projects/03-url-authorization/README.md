# Topic 03 — Authorization: URL-Based

Maps to Spring Security pptx, Topic 03/25.

## Concept
`authorizeHttpRequests().requestMatchers(...)` rules are evaluated top-down —
first match wins — so specific paths must be declared before general ones.

## Run
```
mvn spring-boot:run
```
```
curl http://localhost:8080/api/public/info                  # 200, no auth
curl -u user:user http://localhost:8080/user/profile         # 200
curl -u user:user http://localhost:8080/admin/dashboard       # 403
curl -u admin:admin http://localhost:8080/admin/dashboard     # 200
```
