package com.example.demo;

import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    // orderId -> owning username
    private final Map<String, String> owners = Map.of("101", "alex", "102", "bob");

    public boolean isOwner(String orderId, String username) {
        return username.equals(owners.get(orderId));
    }
}
