# Topic 16 — Authorization with Expressions: URL

Maps to Spring Security pptx, Topic 16/25.

## Concept
A custom `AuthorizationManager<RequestAuthorizationContext>` can read the
matched path variable and make a dynamic, ownership-based decision —
something a static role check can't express.

## Run
```
mvn spring-boot:run
curl -u alex:pass http://localhost:8080/orders/101   # 200 — alex owns order 101
curl -u alex:pass http://localhost:8080/orders/102   # 403 — alex does not own order 102
curl -u bob:pass  http://localhost:8080/orders/102   # 200
```
