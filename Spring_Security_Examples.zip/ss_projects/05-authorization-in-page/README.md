# Topic 05 — Authorization: In Page

Maps to Spring Security pptx, Topic 05/25.

## Concept
`sec:authorize="hasRole('ADMIN')"` hides or shows a Thymeleaf fragment based
on the current user's roles. This is UX only — the real enforcement must
still live on the controller/service.

## Run
```
mvn spring-boot:run
```
Visit http://localhost:8080/dashboard as **admin/admin** (sees the "Manage
Users" link) vs **user/user** (sees the fallback message instead).
