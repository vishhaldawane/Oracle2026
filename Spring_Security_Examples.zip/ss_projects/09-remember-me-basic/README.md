# Topic 09 — Remember-Me with a Cookie: Basic Setup

Maps to Spring Security pptx, Topic 09/25.

## Concept
`.rememberMe()` issues a persistent cookie so a session survives a browser
restart without re-entering credentials. The token is a hash of the username,
an expiry timestamp, the password hash, and a secret key.

## Run
```
mvn spring-boot:run
```
Log in at http://localhost:8080/login with the "Remember me" box checked,
then inspect the `remember-me` cookie in your browser's dev tools.
