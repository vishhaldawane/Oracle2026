package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final DocumentRepository repository;
    public DataSeeder(DocumentRepository repository) { this.repository = repository; }

    @Override
    public void run(String... args) {
        repository.save(new Document("Alex's private contract", "alex"));
        repository.save(new Document("Bob's private contract", "bob"));
    }
}
