package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Document {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String owner;

    public Document() {}
    public Document(String title, String owner) { this.title = title; this.owner = owner; }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getOwner() { return owner; }
}
