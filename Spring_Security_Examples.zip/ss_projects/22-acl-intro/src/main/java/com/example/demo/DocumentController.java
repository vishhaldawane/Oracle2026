package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DocumentController {

    @Autowired private DocumentRepository repository;

    /**
     * PROBLEM this topic sets up: hasRole('USER') only checks the TYPE of
     * access (is this a user at all), not WHICH document they may see.
     * Any authenticated USER can read ANY document, including someone
     * else's. Topics 23-25 introduce ACLs to fix exactly this gap.
     */
    @PreAuthorize("hasRole('USER')")
    @GetMapping("/documents/{id}")
    public Document getDocument(@PathVariable Long id) {
        return repository.findById(id).orElseThrow();
    }
}
