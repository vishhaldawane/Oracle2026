# Topic 22 — Domain Object Security & ACL: Introduction

Maps to Spring Security pptx, Topic 22/25.

## Concept
`@PreAuthorize("hasRole('USER')")` only checks whether the caller is *a*
user — it has no idea which specific `Document` row they're allowed to
touch. This project deliberately demonstrates that gap; Topics 23-25 build
the ACL machinery that closes it.

## Run
```
mvn spring-boot:run
curl -u bob:pass http://localhost:8080/documents/1   # 200 — but this is ALEX's document!
```
That's the bug per-object ACLs exist to fix.
