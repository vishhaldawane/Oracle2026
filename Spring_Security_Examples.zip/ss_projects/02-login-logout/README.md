# Topic 02 — Authentication: Log In and Log Out

Maps to Spring Security pptx, Topic 02/25.

## Concept
UsernamePasswordAuthenticationFilter processes the `/login` POST; the
SecurityContext then holds the Authentication for the session. `logout()`
clears the session, expires cookies, and redirects.

## Run
```
mvn spring-boot:run
```
Visit http://localhost:8080/dashboard — redirected to the custom `/login`
page. Credentials: **user / password**. Successful login redirects to
`/dashboard`; the logout button posts to `/logout` and redirects back to
`/login?logout`.
