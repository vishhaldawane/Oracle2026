package com.example.demo;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Base64;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Educational endpoint: decodes the anatomy of the remember-me cookie
 * (username + expiry are readable; the third field is an MD5 hash and
 * cannot be reversed — that's the whole point of a hash).
 */
@RestController
public class RememberMeInfoController {

    @GetMapping("/remember-me-info")
    public String info(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return "No cookies present. Log in with 'Remember me' checked first.";

        for (Cookie c : cookies) {
            if ("remember-me".equals(c.getName())) {
                String decoded = new String(Base64.getUrlDecoder().decode(c.getValue()));
                String[] parts = decoded.split(":", 3);
                StringBuilder sb = new StringBuilder();
                sb.append("Raw cookie (base64): ").append(c.getValue()).append("\n");
                sb.append("Decoded: ").append(decoded).append("\n");
                if (parts.length == 3) {
                    sb.append("  username: ").append(parts[0]).append("\n");
                    sb.append("  expiryTime (ms since epoch): ").append(parts[1]).append("\n");
                    sb.append("  signature (md5 hash, NOT reversible): ").append(parts[2]).append("\n");
                }
                return sb.toString();
            }
        }
        return "No remember-me cookie found. Log in with 'Remember me' checked first.";
    }
}
