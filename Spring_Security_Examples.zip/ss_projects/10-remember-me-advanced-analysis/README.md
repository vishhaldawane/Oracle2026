# Topic 10 — Remember-Me with a Cookie: Advanced Analysis

Maps to Spring Security pptx, Topic 10/25.

## Concept
The remember-me token is `base64(username:expiryTime:MD5(username:expiryTime:password:key))`.
Changing the user's password invalidates every remember-me cookie at once,
since the password hash is baked into the signature — and there's no way to
revoke a single device's cookie without changing the password for everyone.

## Run
```
mvn spring-boot:run
```
Log in at http://localhost:8080/login with "Remember me" checked, then open
http://localhost:8080/remember-me-info to see the token decoded field by
field (the signature itself cannot be reversed — only verified).
