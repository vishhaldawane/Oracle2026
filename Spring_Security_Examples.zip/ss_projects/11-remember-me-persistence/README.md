# Topic 11 — Remember-Me with Persistence

Maps to Spring Security pptx, Topic 11/25.

## Concept
`PersistentTokenRepository` (backed by `JdbcTokenRepositoryImpl`) stores a
series/token pair per device in a `persistent_logins` table, refreshed on
every login. Logging out one device leaves every other device's row intact —
delete a row to revoke that one device's remember-me session.

## Run
```
mvn spring-boot:run
```
Log in from two different browsers (or one normal + one incognito window)
with "Remember me" checked, then visit http://localhost:8080/tokens to see
one row per device.
