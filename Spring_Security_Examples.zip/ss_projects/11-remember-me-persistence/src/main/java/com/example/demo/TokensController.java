package com.example.demo;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Lists every persistent remember-me token row — one per device/browser. */
@RestController
public class TokensController {

    @Autowired private JdbcTemplate jdbcTemplate;

    @GetMapping("/tokens")
    public List<Map<String, Object>> tokens() {
        return jdbcTemplate.queryForList(
            "select username, series, last_used from persistent_logins");
    }
}
