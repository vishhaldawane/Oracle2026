package com.example.demo;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;
import org.springframework.stereotype.Component;

/**
 * Creates one Document, then builds its ACL by hand so you can see all
 * four tables (acl_class, acl_sid, acl_object_identity, acl_entry) populate,
 * exactly as described in the pptx slide's worked example.
 */
@Component
public class AclDemoRunner implements CommandLineRunner {

    @Autowired private DocumentRepository documentRepository;
    @Autowired private JdbcMutableAclService aclService;
    @Autowired private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        Document doc = documentRepository.save(new Document("Q3 Financial Report"));

        ObjectIdentity oid = new ObjectIdentityImpl(Document.class, doc.getId());
        MutableAcl acl = aclService.createAcl(oid);

        Sid alex = new PrincipalSid("alex");
        acl.insertAce(acl.getEntries().size(), BasePermission.READ, alex, true);
        acl.insertAce(acl.getEntries().size(), BasePermission.WRITE, alex, true);
        aclService.updateAcl(acl);

        System.out.println("---- ACL DATA STRUCTURE (Topic 23) ----");
        System.out.println("acl_class: " + jdbcTemplate.queryForList("select * from acl_class"));
        System.out.println("acl_sid: " + jdbcTemplate.queryForList("select * from acl_sid"));
        System.out.println("acl_object_identity: " + jdbcTemplate.queryForList("select * from acl_object_identity"));
        System.out.println("acl_entry: " + jdbcTemplate.queryForList("select * from acl_entry"));
        System.out.println("----------------------------------------");
    }
}
