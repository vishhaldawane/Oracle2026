# Topic 23 — The ACL Data Structure

Maps to Spring Security pptx, Topic 23/25.

## Concept
Spring Security's ACL module is four related tables:
`acl_class` (which types are secured), `acl_object_identity` (one row per
secured instance), `acl_sid` (the security identities), and `acl_entry`
(the actual permission bits per SID per object).

## Run
```
mvn spring-boot:run
```
Watch the console at startup — `AclDemoRunner` creates one `Document`, grants
`alex` READ+WRITE on it via the ACL API, then prints the contents of all
four tables so you can see exactly how they relate.
