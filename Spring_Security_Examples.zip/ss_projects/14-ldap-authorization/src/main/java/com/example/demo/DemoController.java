package com.example.demo;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @GetMapping("/")
    public String home(Authentication authentication) {
        return "Hello " + authentication.getName() + ", your authorities: " + authentication.getAuthorities();
    }

    @GetMapping("/admin/dashboard")
    public String admin() {
        return "Admin dashboard — requires the 'admins' LDAP group.";
    }
}
