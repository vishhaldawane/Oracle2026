# Topic 14 — Authorization with LDAP

Maps to Spring Security pptx, Topic 14/25.

## Concept
`DefaultLdapAuthoritiesPopulator` looks up the groups a user belongs to
(`ou=groups`, filter `member={0}`) and converts them into `ROLE_*`
authorities, so LDAP group membership drives authorization decisions.

## Run
```
mvn spring-boot:run
curl -u alex:pass123 http://localhost:8080/admin/dashboard   # 200 — alex is in 'admins'
curl -u bob:pass123  http://localhost:8080/admin/dashboard   # 403 — bob is not
```
