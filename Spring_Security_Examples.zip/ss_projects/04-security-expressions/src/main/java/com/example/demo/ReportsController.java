package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReportsController {

    @GetMapping("/reports/quarterly")
    public String quarterly() {
        return "Quarterly report — visible only to MANAGER + REPORTS_VIEW.";
    }
}
