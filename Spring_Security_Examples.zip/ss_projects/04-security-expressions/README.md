# Topic 04 — Authorization: Security Expressions

Maps to Spring Security pptx, Topic 04/25.

## Concept
SpEL expressions combine multiple checks (`and`/`or`) beyond a single role
match, evaluated against the current Authentication.

## Run
```
mvn spring-boot:run
curl -u alex:pass http://localhost:8080/reports/quarterly   # 200 (has both)
curl -u bob:pass  http://localhost:8080/reports/quarterly   # 403 (missing REPORTS_VIEW)
```
