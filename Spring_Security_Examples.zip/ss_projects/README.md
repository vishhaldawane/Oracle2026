# Spring Security — 25 Independent Runnable Examples

This bundle contains **25 fully independent Spring Boot Maven projects**, one
per topic in the "Spring Security" training deck (Spring_Security.pptx).
Each folder is entirely self-contained — copy any single folder out on its
own and it will build and run without needing anything else in this bundle.

## Prerequisites

- Java 17+
- Maven (or your IDE's bundled Maven)
- Internet access to Maven Central the first time you build each project
  (to download Spring Boot / Spring Security dependencies)

## Running any example

```
cd 01-setup-form-login
mvn spring-boot:run
```

Then open the URL / run the curl commands shown in that project's own
`README.md`. Every project uses port **8080** by default — stop one
(Ctrl+C) before starting the next.

## Index

| # | Folder | Topic |
|---|--------|-------|
| 01 | 01-setup-form-login | Spring Security Setup & Form-Based Authentication |
| 02 | 02-login-logout | Authentication – Log In and Log Out |
| 03 | 03-url-authorization | Authorization – URL-Based |
| 04 | 04-security-expressions | Authorization – Security Expressions |
| 05 | 05-authorization-in-page | Authorization – In Page |
| 06 | 06-registration-in-memory | Registration – In-Memory Authentication Provider |
| 07 | 07-registration-jdbc | Registration – JDBC-Backed Authentication Provider |
| 08 | 08-registration-jpa | Registration & Authentication with JPA |
| 09 | 09-remember-me-basic | Remember-Me with a Cookie – Basic Setup |
| 10 | 10-remember-me-advanced-analysis | Remember-Me with a Cookie – Advanced Analysis |
| 11 | 11-remember-me-persistence | Remember-Me with Persistence |
| 12 | 12-remember-me-advanced-scenarios | Remember-Me – Advanced Scenarios |
| 13 | 13-ldap-authentication | Authentication with LDAP |
| 14 | 14-ldap-authorization | Authorization with LDAP |
| 15 | 15-ldap-external-server | Authentication & Authorization – External LDAP Server |
| 16 | 16-authz-expressions-url | Authorization with Expressions – URL |
| 17 | 17-authz-expressions-in-page | Authorization with Expressions – In Page |
| 18 | 18-authz-expressions-methods | Authorization with Expressions – on Methods |
| 19 | 19-rest-service-setup | The REST Service and Its Setup |
| 20 | 20-rest-basic-auth | REST with Basic Authentication |
| 21 | 21-rest-digest-auth | REST with Digest Authentication |
| 22 | 22-acl-intro | Domain Object Security & ACL — Introduction |
| 23 | 23-acl-data-structure | The ACL Data Structure |
| 24 | 24-acl-setup-configuration | The ACL Setup and Configuration |
| 25 | 25-acl-advanced | Advanced ACL |

## Notes on scope

- Each project uses an in-memory H2 database or embedded LDAP server where a
  database/directory is needed, so nothing except Maven Central access is
  required to run it.
- **Topic 15** (external LDAP) is a configuration reference rather than a
  self-contained demo — it needs a real LDAP/Active Directory server to run
  end-to-end, which can't be bundled. It builds and starts fine on its own.
- **Topic 21** (Digest auth) reimplements the RFC 2617 handshake by hand,
  since Spring Security itself removed native Digest support in version 5.0.
  This is clearly called out as a teaching-only implementation in its README.
- **Topics 23–25** (ACL) configure the `spring-security-acl` module's JDBC
  schema and beans from scratch — the most involved topics in the set — and
  each includes a `CommandLineRunner` that prints what it did to the console
  on startup so the concept is visible immediately without writing test code.
- All code was written and reviewed carefully (POM validity, brace/paren
  balance, and a syntax-only `javac` pass across every file), but this
  sandbox has no access to Maven Central, so full `mvn compile` could not be
  verified end-to-end here. Build each project with your own Maven/JDK to
  confirm — please open an issue-style note back to your trainer if
  anything doesn't compile as-is.
