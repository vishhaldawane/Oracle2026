# Topic 08 — Registration & Authentication with JPA

Maps to Spring Security pptx, Topic 08/25.

## Concept
A custom `AppUser` entity + Spring Data JPA repository + a hand-written
`UserDetailsService` bridges your own domain model with Spring Security,
which is what nearly every real application does instead of the built-in
in-memory/JDBC providers.

## Run
```
mvn spring-boot:run
curl -X POST http://localhost:8080/register -d "username=priya&password=pass123"
curl -u priya:pass123 http://localhost:8080/register
```
