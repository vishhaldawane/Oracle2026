package com.example.demo;

import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.model.Permission;

/** A custom permission bit beyond the default READ/WRITE/CREATE/DELETE/ADMINISTER set. */
public class ExportPermission extends BasePermission {
    public static final Permission EXPORT = new ExportPermission(1 << 5, 'X'); // bit 32

    protected ExportPermission(int mask, char code) {
        super(mask, code);
    }
}
