package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Document {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private Long folderId;

    public Document() {}
    public Document(String title, Long folderId) { this.title = title; this.folderId = folderId; }
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public Long getFolderId() { return folderId; }
}
