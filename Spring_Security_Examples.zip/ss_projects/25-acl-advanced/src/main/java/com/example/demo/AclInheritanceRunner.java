package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.GrantedAuthoritySid;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.stereotype.Component;

/**
 * Demonstrates ACL inheritance: granting "Finance Team: READ" on a Folder
 * propagates automatically to every Document whose ACL has that folder's
 * ACL set as its parent with entriesInheriting = true, plus a custom
 * EXPORT permission bit beyond the built-in READ/WRITE/CREATE/DELETE/ADMINISTER set.
 */
@Component
public class AclInheritanceRunner implements CommandLineRunner {

    @Autowired private FolderRepository folderRepository;
    @Autowired private DocumentRepository documentRepository;
    @Autowired private JdbcMutableAclService aclService;

    @Override
    public void run(String... args) {
        Folder folder = folderRepository.save(new Folder("Finance"));
        ObjectIdentity folderOid = new ObjectIdentityImpl(Folder.class, folder.getId());
        MutableAcl folderAcl = aclService.createAcl(folderOid);
        folderAcl.insertAce(0, BasePermission.READ, new GrantedAuthoritySid("ROLE_FINANCE_TEAM"), true);
        folderAcl.insertAce(1, ExportPermission.EXPORT, new GrantedAuthoritySid("ROLE_FINANCE_TEAM"), true);
        aclService.updateAcl(folderAcl);

        Document doc = documentRepository.save(new Document("Q3 statement", folder.getId()));
        ObjectIdentity docOid = new ObjectIdentityImpl(Document.class, doc.getId());
        MutableAcl docAcl = aclService.createAcl(docOid);
        docAcl.setParent(folderAcl);
        docAcl.setEntriesInheriting(true); // no explicit entries needed — it inherits the folder's
        aclService.updateAcl(docAcl);

        System.out.println("Document " + doc.getId() + " inherits READ + EXPORT from Folder "
                + folder.getId() + " for ROLE_FINANCE_TEAM, with zero entries of its own.");
    }
}
