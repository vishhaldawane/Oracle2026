# Topic 25 — Advanced ACL

Maps to Spring Security pptx, Topic 25/25.

## Concept
Real ACL deployments add **inheritance** (a child object's ACL points at a
parent's and inherits its entries — folder to file is the classic case) and
**custom permission bits** beyond the built-in READ/WRITE/CREATE/DELETE/
ADMINISTER set (`ExportPermission.EXPORT` here, bit 32).

## Run
```
mvn spring-boot:run
```
Watch the console at startup: `AclInheritanceRunner` grants
`ROLE_FINANCE_TEAM` READ + EXPORT on a Folder, then creates a Document
inside it with **zero ACL entries of its own** — it inherits both
permissions purely through `setParent()` + `setEntriesInheriting(true)`.
