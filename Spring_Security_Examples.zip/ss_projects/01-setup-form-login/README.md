# Topic 01 — Spring Security Setup & Form-Based Authentication

Maps to Spring Security pptx, Topic 01/25.

## Concept
Spring Security inserts a chain of servlet filters in front of every request.
Form-based authentication is the default: an unauthenticated request to any
endpoint is redirected to an auto-generated HTML login page.

## Run
```
mvn spring-boot:run
```
Visit http://localhost:8080/ — you'll be redirected to /login.

Credentials: **user / password**

After logging in you're redirected back to `/` and see a personalized greeting.

## Try next
- Remove `.formLogin(...)` and see Spring Security fall back to HTTP Basic.
- Add a second user with `.roles("ADMIN")` and inspect `/` as each user.
