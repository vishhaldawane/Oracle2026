# Topic 17 — Authorization with Expressions: In Page

Maps to Spring Security pptx, Topic 17/25.

## Concept
`sec:authorize="hasAuthority('REPORT_EXPORT')"` reuses the exact same
authority name your backend checks, so the view stays in sync with the real
permission model instead of duplicating role logic.

## Run
```
mvn spring-boot:run
```
Visit http://localhost:8080/reports as **alex/pass** (Export button visible)
vs **bob/pass** (button hidden, message shown instead).
