# Topic 24 — The ACL Setup and Configuration

Maps to Spring Security pptx, Topic 24/25.

## Concept
`@PostAuthorize("hasPermission(returnObject, 'READ')")` runs AFTER the
method returns, checking the actual loaded `Document` against the ACL
tables via `AclPermissionEvaluator` — wired into method security through
`DefaultMethodSecurityExpressionHandler`.

## Run
```
mvn spring-boot:run
curl -u alex:pass http://localhost:8080/documents/1   # 200 — alex's own document
curl -u alex:pass http://localhost:8080/documents/2   # 403 — that one's bob's
curl -u bob:pass  http://localhost:8080/documents/2   # 200
```
