package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.stereotype.Component;

/** Seeds two documents: one alex can read, one only bob can read. */
@Component
public class AclSeeder implements CommandLineRunner {

    @Autowired private DocumentRepository documentRepository;
    @Autowired private JdbcMutableAclService aclService;

    @Override
    public void run(String... args) {
        Document doc1 = documentRepository.save(new Document("Alex's report"));
        ObjectIdentity oid1 = new ObjectIdentityImpl(Document.class, doc1.getId());
        MutableAcl acl1 = aclService.createAcl(oid1);
        acl1.insertAce(0, BasePermission.READ, new PrincipalSid("alex"), true);
        aclService.updateAcl(acl1);

        Document doc2 = documentRepository.save(new Document("Bob's report"));
        ObjectIdentity oid2 = new ObjectIdentityImpl(Document.class, doc2.getId());
        MutableAcl acl2 = aclService.createAcl(oid2);
        acl2.insertAce(0, BasePermission.READ, new PrincipalSid("bob"), true);
        aclService.updateAcl(acl2);

        System.out.println("Seeded document " + doc1.getId() + " (alex-readable) and "
                + doc2.getId() + " (bob-readable)");
    }
}
