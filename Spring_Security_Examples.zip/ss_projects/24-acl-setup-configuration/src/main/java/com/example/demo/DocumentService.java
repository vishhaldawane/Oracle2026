package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.stereotype.Service;

@Service
public class DocumentService {

    @Autowired private DocumentRepository repository;

    @PostAuthorize("hasPermission(returnObject, 'READ')")
    public Document getDocument(Long id) {
        return repository.findById(id).orElseThrow();
    }
}
