package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DocumentController {

    @Autowired private DocumentService documentService;

    @GetMapping("/documents/{id}")
    public Document getDocument(@PathVariable Long id) {
        return documentService.getDocument(id);
    }
}
