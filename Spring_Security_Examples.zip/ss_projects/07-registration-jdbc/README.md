# Topic 07 — Registration: JDBC-Backed Authentication Provider

Maps to Spring Security pptx, Topic 07/25.

## Concept
`JdbcUserDetailsManager` persists users and authorities in relational tables
using Spring Security's default schema, so registrations survive a restart
(as long as the database itself isn't in-memory — swap the H2 URL for a real
database to keep data between runs).

## Run
```
mvn spring-boot:run
curl -X POST http://localhost:8080/register -d "username=neha&password=pass123"
curl -u neha:pass123 http://localhost:8080/register
```
Inspect the tables live at http://localhost:8080/h2-console
(JDBC URL: `jdbc:h2:mem:securitydb`).
