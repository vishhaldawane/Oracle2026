# Topic 06 — Registration: In-Memory Authentication Provider

Maps to Spring Security pptx, Topic 06/25.

## Concept
`InMemoryUserDetailsManager` is the simplest provider — perfect for demos and
tests, but every registered user vanishes on restart.

## Run
```
mvn spring-boot:run
curl -X POST http://localhost:8080/register -d "username=alex&password=pass123"
curl -u alex:pass123 http://localhost:8080/register   # just to prove the account works via any secured endpoint
```
Restart the app and `alex` is gone — that's the whole point of this topic.
