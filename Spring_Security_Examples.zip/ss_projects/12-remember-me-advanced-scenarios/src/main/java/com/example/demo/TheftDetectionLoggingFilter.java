package com.example.demo;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.web.authentication.rememberme.CookieTheftException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Wraps request handling so a CookieTheftException (thrown when an old,
 * already-consumed series/token pair is replayed) is logged loudly instead
 * of just producing a redirect to /login. In a real app this is where you'd
 * fire a security alert / notify the user of a compromised device.
 */
@Component
public class TheftDetectionLoggingFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        try {
            chain.doFilter(request, response);
        } catch (CookieTheftException e) {
            System.out.println("[SECURITY ALERT] Remember-me token reuse detected — "
                    + "every session for this user has been invalidated: " + e.getMessage());
            throw e;
        }
    }
}
