# Topic 12 — Remember-Me: Advanced Scenarios

Maps to Spring Security pptx, Topic 12/25.

## Concept
Reusing an old, already-rotated series/token pair is a strong signal of
cookie theft. Spring Security throws `CookieTheftException` and invalidates
every remember-me session for that user.

## Run (manual theft-detection test)
```
mvn spring-boot:run
# 1. Log in with curl, saving cookies:
curl -c cookies1.txt -X POST http://localhost:8080/login -d "username=user&password=password&remember-me=true"
# 2. Copy cookies1.txt to cookies-old.txt (simulates an attacker stealing it)
cp cookies1.txt cookies-old.txt
# 3. Use the real cookie once — it rotates to a new token:
curl -b cookies1.txt -c cookies1.txt http://localhost:8080/dashboard
# 4. Replay the OLD, now-superseded cookie — triggers CookieTheftException:
curl -b cookies-old.txt http://localhost:8080/dashboard
```
Watch the console log for the `[SECURITY ALERT]` line.
