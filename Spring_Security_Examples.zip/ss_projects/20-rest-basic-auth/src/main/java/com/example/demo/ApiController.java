package com.example.demo;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {

    @GetMapping("/orders")
    public List<String> orders() {
        return List.of("Order #101", "Order #102");
    }
}
