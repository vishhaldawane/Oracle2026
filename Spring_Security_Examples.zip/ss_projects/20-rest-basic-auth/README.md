# Topic 20 — REST with Basic Authentication

Maps to Spring Security pptx, Topic 20/25.

## Concept
HTTP Basic sends `base64(username:password)` on the `Authorization` header
on every single request. No server session is created (`STATELESS`), so
this scales cleanly for service-to-service calls — but it must only ever run
over HTTPS in real deployments, since the credentials travel on every call.

## Run
```
mvn spring-boot:run
curl -u alex:pass123 http://localhost:8080/orders
# Or see the raw header Basic auth sends:
curl -v -u alex:pass123 http://localhost:8080/orders 2>&1 | grep Authorization
```
