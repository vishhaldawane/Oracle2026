package com.example.demo;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {

    @GetMapping("/secure/ping")
    public String ping(Authentication authentication) {
        return "pong, " + authentication.getName() + " (authenticated via Digest)";
    }
}
