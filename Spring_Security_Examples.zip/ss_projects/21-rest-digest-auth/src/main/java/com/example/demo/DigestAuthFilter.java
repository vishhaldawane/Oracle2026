package com.example.demo;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * TEACHING IMPLEMENTATION ONLY.
 *
 * Spring Security removed its built-in Digest authentication support in
 * version 5.0 because it requires the server to hold a *recoverable* form
 * of the password (to recompute the same hash the client sent) — a materially
 * weaker guarantee than a one-way-hashed password store. Modern systems use
 * TLS + Basic, or OAuth2/JWT, instead.
 *
 * This filter reimplements the classic RFC 2617 Digest handshake so you can
 * see exactly how it works: the client never transmits the raw password,
 * only a hash computed from a server-issued nonce.
 */
@Component
public class DigestAuthFilter extends OncePerRequestFilter {

    private static final String REALM = "demo-realm";
    // In-memory plaintext-equivalent credential store — required by the Digest
    // protocol itself (see class-level note above). Never do this for a real system.
    private static final Map<String, String> USERS = Map.of("alex", "pass123");
    private final String nonce = UUID.randomUUID().toString().replace("-", "");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Digest ")) {
            Map<String, String> params = parseDigestHeader(header.substring(7));
            String username = params.get("username");
            String password = USERS.get(username);

            if (password != null) {
                String ha1 = md5(username + ":" + REALM + ":" + password);
                String ha2 = md5(request.getMethod() + ":" + params.get("uri"));
                String expected = md5(ha1 + ":" + params.get("nonce") + ":" + ha2);

                if (expected.equals(params.get("response"))) {
                    var auth = new UsernamePasswordAuthenticationToken(
                            username, null, java.util.List.of(new SimpleGrantedAuthority("ROLE_USER")));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                    chain.doFilter(request, response);
                    return;
                }
            }
        }

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setHeader("WWW-Authenticate",
                "Digest realm=\"" + REALM + "\", nonce=\"" + nonce + "\", qop=\"auth\"");
    }

    private Map<String, String> parseDigestHeader(String header) {
        Map<String, String> map = new HashMap<>();
        for (String part : header.split(",")) {
            String[] kv = part.trim().split("=", 2);
            if (kv.length == 2) {
                map.put(kv[0].trim(), kv[1].trim().replaceAll("^\"|\"$", ""));
            }
        }
        return map;
    }

    private String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
