# Topic 21 — REST with Digest Authentication

Maps to Spring Security pptx, Topic 21/25.

## Concept
Digest authentication hashes credentials with a server-issued nonce instead
of sending the password itself. **Modern Spring Security no longer ships
this feature** (removed in 5.0) because it requires the server to keep a
recoverable form of the password — this project reimplements the RFC 2617
handshake purely so you can see the mechanics; do not use it in production.

## Run
```
mvn spring-boot:run
# First request gets a 401 + nonce challenge:
curl -i http://localhost:8080/secure/ping
```
Because `curl -u` cannot do Digest itself directly against a custom filter
like this, use `curl --digest -u alex:pass123 http://localhost:8080/secure/ping`
to see the full handshake in `curl -v --digest -u alex:pass123 ...`.
