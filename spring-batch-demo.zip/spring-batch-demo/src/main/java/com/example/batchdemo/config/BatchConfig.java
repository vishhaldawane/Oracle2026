package com.example.batchdemo.config;

import com.example.batchdemo.model.Person;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class BatchConfig {

    // ---- READER: reads each row of the CSV into a Person object ----
    @Bean
    public FlatFileItemReader<Person> reader() {
        return new FlatFileItemReaderBuilder<Person>()
                .name("personReader")
                .resource(new ClassPathResource("input.csv"))
                .linesToSkip(1) // skip header row
                .delimited()
                .names("firstName", "lastName")
                .targetType(Person.class)
                .build();
    }

    // ---- PROCESSOR: uppercases the names ----
    @Bean
    public ItemProcessor<Person, Person> processor() {
        return person -> {
            person.setFirstName(person.getFirstName().toUpperCase());
            person.setLastName(person.getLastName().toUpperCase());
            return person;
        };
    }

    // ---- WRITER: just prints to console ----
    @Bean
    public ItemWriter<Person> writer() {
        return chunk -> chunk.getItems().forEach(System.out::println);
    }

    // ---- STEP: reads/processes/writes in chunks of 2 ----
    @Bean
    public Step step1(JobRepository jobRepository,
                       PlatformTransactionManager txManager,
                       FlatFileItemReader<Person> reader,
                       ItemProcessor<Person, Person> processor,
                       ItemWriter<Person> writer) {
        return new StepBuilder("step1", jobRepository)
                .<Person, Person>chunk(2, txManager)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }

    // ---- JOB: wraps the step ----
    @Bean
    public Job job(JobRepository jobRepository, Step step1) {
        return new JobBuilder("personJob", jobRepository)
                .start(step1)
                .build();
    }
}
