# Spring Batch Demo

A minimal Spring Batch example: reads names from `input.csv`, uppercases them, and prints the result to the console.

## Import into IntelliJ IDEA Ultimate

1. Unzip this archive somewhere on disk.
2. In IntelliJ: **File → Open** → select the unzipped `spring-batch-demo` folder.
3. IntelliJ will detect the `pom.xml` and import it as a Maven project automatically (may take a minute to download dependencies).
4. Once indexing finishes, open `src/main/java/com/example/batchdemo/Application.java` and click the green ▶ run icon next to `main`.

Requires **Java 17+** (set in IntelliJ under *File → Project Structure → SDK*).

## Run from the command line instead

```bash
mvn spring-boot:run
```

## Expected output

```
Person{JOHN DOE}
Person{JANE SMITH}
Person{BOB BUILDER}
```

## What's in here

- `BatchConfig.java` — defines the reader (CSV), processor (uppercase), writer (console), step (chunk size 2), and job.
- `Person.java` — simple POJO the CSV rows are mapped into.
- `input.csv` — sample data.
- `application.properties` — configures an in-memory H2 database that Spring Batch uses to store job/step execution metadata (required by `JobRepository`, even though this demo doesn't touch a "real" database itself).

## Next steps to try

- Change `chunk(2, txManager)` to `chunk(1, ...)` and watch it commit after every single item.
- Add `.faultTolerant().skip(Exception.class).skipLimit(5)` to the step builder and put a bad row in the CSV.
- Swap the console `ItemWriter` for a `JdbcBatchItemWriter` to write into a real table.
