package com.vishal.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
