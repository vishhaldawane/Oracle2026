package com.vishal.demo.service;

import com.vishal.demo.entity.Director;

public interface DirectorService {

	Director save(Director d);
	
	Director find(int dirid);
	
}