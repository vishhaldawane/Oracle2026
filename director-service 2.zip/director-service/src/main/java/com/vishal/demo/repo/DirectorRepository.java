package com.vishal.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.demo.entity.Director;


public interface DirectorRepository extends JpaRepository<Director, Integer> {

}